import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'calender';

    public minDate: Date = new Date ("12/31/1800");
    public maxDate: Date = new Date ("12/31/2100");
    public value: Date = new Date ();

}
