import { Component, OnInit } from '@angular/core';
import listWeekPlugin from '@fullcalendar/list';

@Component({
  selector: 'app-week',
  templateUrl: './week.component.html',
  styleUrls: ['./week.component.css']
})
export class WeekComponent implements OnInit {

  calenderPlugins = [listWeekPlugin];

  constructor() { }

  ngOnInit() {
  }

}
