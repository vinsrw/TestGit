import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import { EventInput } from '@fullcalendar/core';
import timeGridPlugin from '@fullcalendar/timegrid';
declare var $:any
@Component({
  selector: 'app-week',
  templateUrl: './week.component.html',
  styleUrls: ['./week.component.css']
})

export class WeekComponent implements OnInit {

 /// calendarConfig.showTimesOnWeekView=true;

  defaultView: 'dayGridWeek';

  calendarEvents: EventInput[] = [
    {title: '',  start: new Date('')}
 ]

  constructor() { }

  dayRender(args){
    var cell: HTMLElement = args.el;
    cell.ondblclick = (ev: MouseEvent) => {
      this.addEvent(args.date);
    }
  }
  addEvent(date){

    var title = prompt('Enter title');

    if (title === '') {
    return;
    }
    // else{
    //   return null;
    // }

    this.calendarEvents = this.calendarEvents.concat({
      title: title,
      start: date
    })
    console.log(this.calendarEvents);

  }


  calendarPlugins = [timeGridPlugin];

  ngOnInit() {
  }

  ngAfterViewInit() {



    $(".fc-widget-content").on('click', function (event) {
      $(event.target).append("Some appended text.");

      console.log($(event.target))
    });
    // });
  }

}
