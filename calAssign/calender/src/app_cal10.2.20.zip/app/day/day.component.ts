import { Component, OnInit } from '@angular/core';
import timeGridPlugin from '@fullcalendar/timegrid';
import dayGridPlugin from '@fullcalendar/daygrid';
import { EventInput } from '@fullcalendar/core';
// import { FullCalendar} from '@fullcalendar/angular';
declare var $:any;
@Component({
  selector: 'app-day',
  templateUrl: './day.component.html',
  styleUrls: ['./day.component.css']
})
export class DayComponent implements OnInit {
  // viewDate: Date = new Date();

  defaultView: 'timeGridDay';
  calendarEvents: EventInput[] = [
    {title: '',  start: new Date('')}
 ]

  constructor() { }

  dayRender(args){
    var cell: HTMLElement = args.el;
    cell.ondblclick = (ev: MouseEvent) => {
      this.addEvent(args.date);
    }
  }
  addEvent(date){

    var title = prompt('Enter title');

    if (title === '') {
    return;
    }
    // else{
    //   return null;
    // }

    this.calendarEvents = this.calendarEvents.concat({
      title: title,
      start: date
    })
  }

  calendarPlugins = [dayGridPlugin,timeGridPlugin];


  ngOnInit() {
  }
    // setTimeout(() => {
    //   $("#calendar").fullCalendar({
    //   header: {
    //   left   :'prev,next today',
    //   center :'title',
    //   right  :'month,agendaWeek,agendaDay'
    //                        },
    //   navLinks   :true,
    //   editable   :true,
    //   eventLimit :true,
    //   eventRender:function(event, element, view) {
    //   element.find('span.fc-title').attr('data-toggle', 'tooltip');
    //   element.find('span.fc-title').attr('title', event.title);
    //                       },
    //    events: [
    //      {
    //        title: 'All Day Event',
    //        description: 'description for All Day Event',
    //        start: '2020-2-01'
    //      },
    //      {
    //        title: 'Long Event',
    //        description: 'description for Long Event',
    //        start: '2020-2-07',
    //        end: '2020-2-10'
    //      },
    //      {
    //        groupId: '999',
    //        title: 'Repeating Event',
    //        description: 'description for Repeating Event',
    //        start: '2020-2-09T16:00:00'
    //      },
    //      {
    //        groupId: '999',
    //        title: 'Repeating Event',
    //        description: 'description for Repeating Event',
    //        start: '2020-2-16T16:00:00'
    //      },
    //      {
    //        title: 'Conference',
    //        description: 'description for Conference',
    //        start: '2020-2-11',
    //        end: '2020-2-13'
    //      },
    //      {
    //        title: 'Meeting',
    //        description: 'description for Meeting',
    //        start: '2020-2-12T10:30:00',
    //        end: '2020-2-12T12:30:00'
    //      },
    //      {
    //        title: 'Meeting',
    //        description: 'description for Meeting',
    //        start: '2020-2-12T14:30:00'
    //      },
    //      {
    //        title: 'Birthday Party',
    //        description: 'description for Birthday Party',
    //        start: '2019-12-13T07:00:00'
    //      },
    //    ]  // request to load current events
    //                    }).on('click', '.fc-agendaWeek-button, .fc-month-button, .fc-agendaDay-button, .fc-prev-button, .fc-next-button', function() { $('[data-toggle="tooltip"]').tooltip();
    //    });
    //   $('[data-toggle="tooltip"]').tooltip();
    //     }, 100);
    //   }

      }


  //   setTimeout(()=> {
  //     $("#calender").fullCalender({
  //       header: {
  //         left : 'prev, next'
  //       }

  //     })
  //   })
  // }


