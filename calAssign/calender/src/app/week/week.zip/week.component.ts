import {
  Component,
  OnInit,
  ElementRef,
  Renderer,
  AfterViewInit,
  ViewChild
} from "@angular/core";
import dayGridPlugin from '@fullcalendar/daygrid';
import { EventInput } from '@fullcalendar/core';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from "@fullcalendar/interaction";
declare var $:any
@Component({
  selector: 'app-week',
  templateUrl: './week.component.html',
  styleUrls: ['./week.component.css']
})

export class WeekComponent implements AfterViewInit  {

  evVar2: string = '';
  @ViewChild("PopupButton",{static:true}) PopupButton:ElementRef;
  @ViewChild("inEvent2",{static:true}) inEvent2:ElementRef;
 /// calendarConfig.showTimesOnWeekView=true;
  defaultView: 'dayGridWeek';

  calendarEvents: EventInput[] = [{ title: "", start: new Date("") }];


 constructor(private ele: ElementRef, private render: Renderer) {}

  calendarPlugins = [interactionPlugin, dayGridPlugin, timeGridPlugin];
  cellTarget2: any
  ngOnInit() {
  }


  ngAfterViewInit() {
    //console.log(this.myModal);
    console.log(this.PopupButton)

    // this.PopupButton.nativeElement.click()
    $(".fc-widget-content").one("click", (event)=> {

 
      console.log(this.inEvent2);
      this.cellTarget2 = event.target;

      this.PopupButton.nativeElement.click();


    });


  }


  finalChange2()
  {
    console.log(this.cellTarget2,this.evVar2);

    $(this.cellTarget2).append(this.evVar2);

      //  this.cellTarget = event.target;

}

}
