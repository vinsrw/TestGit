import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import { EventInput } from '@fullcalendar/core';

@Component({
  selector: 'app-week',
  templateUrl: './week.component.html',
  styleUrls: ['./week.component.css']
})

export class WeekComponent implements OnInit {

 /// calendarConfig.showTimesOnWeekView=true;

  defaultView: 'timeGridWeek';
  calendarEvents: EventInput[] = [
    {title: '',  start: new Date('')}
 ]

  constructor() { }

  dayRender(args){
    var cell: HTMLElement = args.el;
    cell.ondblclick = (ev: MouseEvent) => {
      this.addEvent(args.date);
    }
  }
  addEvent(date){

    var title = prompt('Enter title');

    if (title === '') {
    return;
    }
    // else{
    //   return null;
    // }

    this.calendarEvents = this.calendarEvents.concat({
      title: title,
      start: date
    })
  }

  calendarPlugins = [dayGridPlugin];

  ngOnInit() {
  }

}
