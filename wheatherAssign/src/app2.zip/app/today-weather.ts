export class TodayWeather {
    constructor( public cityName: string,
        public temp: string,
        public icon: string,
        public humidity: string,
        public tempKind: string,
        public tempMax: string,
        public tempMin: string){}
    }

