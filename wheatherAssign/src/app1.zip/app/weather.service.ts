import { TodayWeather } from './today-weather';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { Observable, Subject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  today: TodayWeather = new TodayWeather('pune', '80', 'ok', '54', 'sunny', '96', '72');

  weatherNow()
  {
    return this.today;
  }
  constructor(private http: HttpClient) { }
  localWeather(lat:string, lon:string)
  {
      return this.http.get(`http://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=785090dc7451b22d4192a2f6d54e7bde&units=metric`)
  }
}
