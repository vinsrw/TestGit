import { ForecastComponent } from './forecast/forecast.component';
import { TodayComponent } from './today/today.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path: 'today', component: TodayComponent},
  {path: 'forecast', component: ForecastComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const weatherRouting = [TodayComponent, ForecastComponent]
