import { WeatherService } from './../weather.service';
import { Forecast } from './../forecast';
import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl}  from '@angular/forms';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.css']
})

export class ForecastComponent implements OnInit {

  constructor(private weatherService:WeatherService) { 
    
  }
  forecastForm: FormGroup
  cityForecast: Forecast[] = [];

  ngOnInit() {
    this.forecastForm = new FormGroup({
      forecastCity: new FormControl('Pune')
    })
  }
  onSubmit()
  {
    console.log(this.forecastForm);
    
    this.weatherService.fiveDayForecast(this.forecastForm.value.forecastCity).subscribe((data)=>{
      console.log(data);
      // for(let i = 0; i < data.valueOf.length;  i = i + 8)
      // {
      //   const temp = new Forecast(data.valueOf[i].dt_txt,
      //    data.valueOf[i].weather[0].icon,
      //    data.valueOf[i].main.temp_max,
      //    data.valueOf[i].main.temp_min )
      //    this.cityForecast.push(temp);
      // }
      //console.log(this.cityForecast);

    }
    );
  }

}
