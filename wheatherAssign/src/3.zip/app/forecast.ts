export class Forecast {
    constructor(public day:string,
                public icon:string,
                public tempmax:string,
                public tempmin:string){}
}

