import { Forecast } from './forecast';

describe('Forecast', () => {
  it('should create an instance', () => {
    expect(new Forecast()).toBeTruthy();
  });
});
