import { TodayWeather } from './today-weather';

describe('TodayWeather', () => {
  it('should create an instance', () => {
    expect(new TodayWeather()).toBeTruthy();
  });
});
