import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { CalendarModule, DateAdapter } from 'angular-calendar';
// import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import { MyCalenderComponent } from './my-calender/my-calender.component';

@NgModule({
  declarations: [
    AppComponent,
    MyCalenderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FullCalendarModule
    // CalendarModule.forRoot({
    //   provide: DateAdapter,
    //   useFactory: adapterFactory
    // })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
