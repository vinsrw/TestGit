import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-calender',
  templateUrl: './my-calender.component.html',
  styleUrls: ['./my-calender.component.css']
})
export class MyCalenderComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
