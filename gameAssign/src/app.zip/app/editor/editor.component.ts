import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.css']
})
export class EditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  onClick()
  {
    
   var res = prompt("Enter you name");
   if(window.confirm("Really go to another page"))
   {
      window.location.href = 'localhost:4200/people-talk';
   }
   else
   {

   }
  }

}
