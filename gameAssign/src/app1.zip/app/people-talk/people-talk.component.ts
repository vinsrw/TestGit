import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-people-talk',
  templateUrl: './people-talk.component.html',
  styleUrls: ['./people-talk.component.css']
})
export class PeopleTalkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
