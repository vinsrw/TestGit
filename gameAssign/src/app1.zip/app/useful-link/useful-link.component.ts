import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useful-link',
  templateUrl: './useful-link.component.html',
  styleUrls: ['./useful-link.component.css']
})
export class UsefulLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
