import { LinksComponent } from './links/links.component';
import { ImagesComponent } from './images/images.component';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {VideoComponent} from './video/video.component';

@Injectable({
  providedIn: 'root'
})
// export class ImageService {

//   searchKey : string = 'cat' ;

//   constructor(private http: HttpClient) { }

//   getImages(): Observable<Object>
//   {
    

//    // return this.http.get(`https://www.googleapis.com/customsearch/v1?key=AIzaSyAWj1et2xbJayGE5CFBaNKwZ1f_YfxtjPI&cx=017576662512468239146:omuauf_lfve&q=${imageKey}&callback=hndlr`);
//   // return this.http.get(`https://www.googleapis.com/customsearch/v1?key=AIzaSyAqkfRVQB0PaHWEF-dquu1Y9zDiGbBZ0AI&cx=017576662512468239146:omuauf_lfve&q=cars`);

//     //  return this.http.get(`https://api.unsplash.com/search/photos?query=${imageKey}&client_id=c2d234ff4e3fb504799ffd3fa309caf46de9da54dbd46b68b7445b14357b4b3c`);

//     let imageurl = 'https://api.unsplash.com/search/photos?query=' + this.searchKey + 
//     '&client_id={{d2f48128fc2418e5519ff61d743cd2ec30a50dac471ff2eefc71d3e42e2116d1}}';
//     return this.http.get(imageurl)
//     .pipe(map((res) => {
//       return res;
//     }))
//   }
  

//   getLinks() : Observable<Object>
//   {

//     let linkurl = 'http://api.serpstack.com/search?access_key={{1ec376ac3a74621a2797622e443dc9cd}}&query=' + this.searchKey;
//     return this.http.get(linkurl)
//     .pipe(map((res) => {
//       return res;
//     }))

//    // return this.http.get(`http://api.serpstack.com/search?access_key=1ec376ac3a74621a2797622e443dc9cd&query=${linkKey}`);

//   }

//   getVideos() : Observable<Object>
//   {
//      // return this.http.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&key=AIzaSyDOawekAIAempdb07pgPzFtzVyyfGd2pSM&q=${link}`)

//    // return this.http.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&key=AIzaSyCAhydUKofxnF4DGHF1sPk1H83F9809PaQ&q=${link}`)

//     // return this.http.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&key=AIzaSyB6zPxyluEDSsz9ntgB19aQTUqAE0_g3dw&q=${link}`)

//     return this.http.get('https://www.googleapis.com/youtube/v3/search?key=' + "AIzaSyC9pTL_w-okkQrWoNPcts1NfLirDoN-4DY" +'&q='+ this.searchKey + '&part=snippet&type=video,id&maxResults=5')
//   }

// }


export class ImageService {

  //searchresult : string = 'cat' ;
  searchKey : string = '' ;

  constructor(private http: HttpClient) { }

  getImages(): Observable<Object>
  {
   // return this.http.get(`https://www.googleapis.com/customsearch/v1?key=AIzaSyAWj1et2xbJayGE5CFBaNKwZ1f_YfxtjPI&cx=017576662512468239146:omuauf_lfve&q=${imageKey}&callback=hndlr`);
  // return this.http.get(`https://www.googleapis.com/customsearch/v1?key=AIzaSyAqkfRVQB0PaHWEF-dquu1Y9zDiGbBZ0AI&cx=017576662512468239146:omuauf_lfve&q=cars`);

    return this.http.get(`https://api.unsplash.com/search/photos?query=`+this.searchKey+`&client_id=c2d234ff4e3fb504799ffd3fa309caf46de9da54dbd46b68b7445b14357b4b3c`);
  }

  getLinks() : Observable<Object>
  {

    return this.http.get(`http://api.serpstack.com/search?access_key=1ec376ac3a74621a2797622e443dc9cd&query=`+this.searchKey);

  }

  getVideos(): Observable<Object>
  {
     // return this.http.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&key=AIzaSyDOawekAIAempdb07pgPzFtzVyyfGd2pSM&q=${link}`)

   // return this.http.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&key=AIzaSyCAhydUKofxnF4DGHF1sPk1H83F9809PaQ&q=`+this.searchKey)

     return this.http.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&key=AIzaSyB6zPxyluEDSsz9ntgB19aQTUqAE0_g3dw&q=`+this.searchKey)
  }
}
