import { Router, Event } from '@angular/router';
import { ImageService } from './../image.service';
import { Link } from './../link';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // imageForm: string = '';
  // //images: Link[] = [];
  searchKey: string;
  // images: any[];
 
  constructor(private  imageService: ImageService, private router: Router) { }

  ngOnInit() {
  }


  onSubmit(value)
  {
  alert(value);
    this.router.navigateByUrl('/link');
    // this.images = [];
    // this.imageService.getImages(this.searchKey).subscribe(values => {
    // for (let img of values["results"]) {
    // this.images.push(img);
    // }
    // console.log(values);
    // });
    }
  }


  // this.router.navigateByUrl('/video');
      
    //   this.imageService.getImages(this.searchKey).subscribe(values => {
    //   console.log(values);
    //     for (let i = 0; i < values.results.length; i++) {
    //       const temp = new Link(
    //         values.results[i].id,
    //         values.results[i].alt_description,
    //         values.results[i].urls.thumb)
    //         this.images.push(temp);
    //        // console.log(temp);
    //        }
          // }
    //  });



      

