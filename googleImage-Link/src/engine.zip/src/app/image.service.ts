import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  constructor(private http: HttpClient) { }

  getImages(imageKey: string)
  {
    return this.http.get(`https://www.googleapis.com/customsearch/v1?key=AIzaSyAWj1et2xbJayGE5CFBaNKwZ1f_YfxtjPI&cx=017576662512468239146:omuauf_lfve&q=${imageKey}&callback=hndlr`);

  }
}
