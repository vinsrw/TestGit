export class Link {
    constructor(
        public videoId: string,
        public title: string,
        public description: string,
        public thumbnails: string){}
}